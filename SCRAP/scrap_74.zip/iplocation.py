import requests
from fake_headers import Headers
import bs4

headers = Headers(browser="firefox", os="win")
headers_data = headers.generate()

response = requests.get("https://www.iplocation.net/", headers=headers_data)
html_data = response.text
soup = bs4.BeautifulSoup(html_data, "lxml")

tag_div = soup.find("div", id="ip-placeholder")
tag_p = soup.find_all("p")[0]
tag_span = tag_p.find_all("span")[0]
print(tag_span.text)
