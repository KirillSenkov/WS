"""
<span id="ip">93.109.69.61</span>
"""
import requests
from fake_headers import Headers
import bs4

headers = Headers(browser="firefox", os="win")
headers_data = headers.generate()

response = requests.get("https://www.myip.com/", headers=headers_data)
html_data = response.text
soup = bs4.BeautifulSoup(html_data, "lxml")
tag = soup.find("span", id="ip")
print(tag.text)
